from rpa_coop.rpa_coop import *
fluid = Fluid()
whatsapp = Whatsapp()
sms = Sms()
send_sms = sms.enviar_SMS
dados = Dados()
criar_conexao_bd = dados.criar_engine
query_sql_fn = Dados()
sql_query_fn = Dados()
acc = Acc()
monitorar = Monitorar()
monitor_rpa = Monitorar()
escrever_por_extenso = Escrever_por_extenso()
numero_por_extenso = escrever_por_extenso.numero_por_extenso
taxa_percentual_por_extenso = escrever_por_extenso.taxa_por_extenso
gerador_de_codigo = Gerador_de_codigo()



