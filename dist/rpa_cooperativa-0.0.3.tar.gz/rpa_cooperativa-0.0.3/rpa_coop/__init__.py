from rpa_coop.rpa_coop import *
fluid = Fluid()
whatsapp = Whatsapp()
sms = Sms()
dados = Dados()
acc = Acc()
